PRESENSI DENGAN FOTO
![aaaa](./ss/ambil-foto.png)
TABLE PRESENSI DENGAN FOTO
![aaaa](./ss/table-New.png)
Thumbnail Foto di Dashboard Admin Dan Pop-Up
![aaaa](./ss/admin-New.png)
![aaaa](./ss/url.png)
![aaaa](./ss/foto-new.png)
