END POINT CHECK-IN
![end:](../Tugas/ss/checkin-p4.png)
END POINT CHECK-OUT
![end:](../Tugas/ss/checkout-p4.png)
END POINT REPORT
![end:](../Tugas/ss/report-p4.png)
DB
![end:](../Tugas/ss/db-p4.png)
