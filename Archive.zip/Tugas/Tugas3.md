MENAMPILKAN END POINT CHECK-IN
![menampilkan end point check-in:](ss/checkin.png)
MENAMPILKAN END POINT CHECK-IN JIKA LEBIH DARI SATU KALI
![menampilkan end point check-in lebih dari 1:](ss/checkin1.png)
MENAMPILKAN END POINT CHECK-OUT
![menampilkan end point check-out:](ss/checkout.png)
MENAMPILKAN END POINT CHECK-OUT JIKA BELUM CHECK-IN
![menampilkan end point check-out blm check in:](ss/checkout1.png)
MENAMPILKAN REPORT'S
![menampilkan end point repots:](ss/report.png)