END-POINT Check-in
![aaaa](./ss/check-in-auth.png)
END-POINT Check-out
![aaaa](./ss/checkout-auth.png)
Tampilan Dashboard Mahasiswa
![aaaa](./ss/mahasiswa-dashboard.png)
Tampilan Dashboard Admin
![aaaa](./ss/report-admin.png)
Database Presensi
![aaaa](./ss/database-presensi.png)