# Tugas 2
 
 Menampilkan End Point Create Book
 ![Menampilkan End Point Create Book:](ss/c.png)
 Menampilkan End Point Get All Book
 ![Menampilkan End Point Get All Book:](ss/r.png)
 Menampilkan End Point Get Book By Id
 ![Menampilkan End Point Get Book By Id:](ss/c1.png)
 Menampilkan End Point Update Book By Id
 ![Menampilkan End Point Update Book By Id:](ss/u.png)
 Menampilkan End Point Delete Book By Id
 ![Menampilkan End Point Delete Book By Id:](ss/d.png)
